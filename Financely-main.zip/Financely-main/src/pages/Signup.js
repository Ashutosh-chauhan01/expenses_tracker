import React from 'react'
import "../App.css";
import SignupSignin from "../components/SignupSignin"

const Signup = () => {
  return (
    <div className='wrapper'>
      <SignupSignin />
    </div>
  )
}

export default Signup;